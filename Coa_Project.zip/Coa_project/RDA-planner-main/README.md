# RDA Planner

A robust dynamic avoidance planner for robotic navigation with various examples and configurations.

## Project Structure

```
RDA-planner/
├── RDA_planner/          # Main package source code
│   ├── __init__.py      # Package initialization
│   ├── mpc.py           # Model Predictive Control implementation
│   └── rda_solver.py    # RDA solver implementation
├── testing/              # Testing use cases
│   ├── corridor/        # Corridor navigation tests
│   ├── dynamic_obs/     # Dynamic obstacle avoidance tests
│   ├── lidar_nav/       # LIDAR-based navigation tests
│   ├── path_track/      # Path tracking tests
│   └── reverse/         # Reverse motion tests
└── setup.py             # Python package setup file
```

## LIDAR Navigation Tests

The `testing/lidar_nav` directory contains several test implementations for LIDAR-based navigation:

- `lidar_path_track.py` - Basic path tracking with LIDAR
- `lidar_path_track_diff.py` - Path tracking for differential drive robots
- `lidar_path_track_omni.py` - Path tracking for omnidirectional robots

Each implementation comes with its corresponding YAML configuration file.

## Installation

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd RDA-planner
   ```

2. Install the package:
   ```bash
   pip install -e .
   ```

## Usage

Run the desired example from the `example` directory. For example:

```bash
python example/lidar_nav/lidar_path_track_omni.py
```

## Configuration

Each example comes with a YAML configuration file where you can adjust parameters such as:
- Robot dynamics
- Controller parameters
- Environment settings
- Visualization options

## Dependencies

- Python 3.6+
- NumPy
- SciPy
- Matplotlib (for visualization)
- PyYAML (for configuration)

## License

[Specify your license here]

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
